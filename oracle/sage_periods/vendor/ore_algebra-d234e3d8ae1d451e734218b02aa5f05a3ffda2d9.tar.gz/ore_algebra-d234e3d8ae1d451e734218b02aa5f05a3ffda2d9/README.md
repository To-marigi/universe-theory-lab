Ore algebra
============

https://github.com/mkauers/ore_algebra/

Description
-----------

A Sage implementation of Ore algebras, Ore polynomials, and differentially
finite functions

Main features for the most common algebras include basic arithmetic and actions;
gcrd and lclm; D-finite closure properties; creative telescoping; natural
transformations between related algebras; guessing; desingularization; solvers
for polynomials, rational functions and (generalized) power series. Univariate
differential operators also support the numerical computation of analytic
solutions with rigorous error bounds and related features.

License
-------

Distributed under the terms of the GNU General Public License (GPL, see the
COPYING file), either version 2 or (at your option) any later version

- https://www.gnu.org/licenses/

Requirements
------------

Sage 9.0 or later is required.

Installation
------------

### With Sage built from source or binaries from sagemath.org

To download and install the latest development version on a system where Sage
was built from source or installed from official packages, run

    sage -pip install --no-build-isolation git+https://github.com/mkauers/ore_algebra.git

or

    sage -pip install --user --no-build-isolation git+https://github.com/mkauers/ore_algebra.git

Note the important `--no-build-isolation` flag, which causes `pip` to use the
installed Sage library while building the package.

The optional `--user` flag causes the package to be installed in your `.sage`
directory instead of the Sage installation tree.

Alternatively, run (square brackets indicate optional flags)

    sage -pip install [--user] --no-build-isolation [--editable] .

from the root of a local git checkout. The `--editable` flag causes the
"installed" version to point to your local checkout, making it easier,
if you edit the code, to run the modified version. See the pip documentation
for more installation options.

Microsoft Windows users should run the above commands in a "SageMath shell", see

- https://wiki.sagemath.org/SageWindows

Apple macOS users may need additional steps before they are able to add external
packages to their Sage installations. See

- https://github.com/3-manifolds/fix_mac_sage/releases
- https://ask.sagemath.org/question/51130

for more information.

Apple users should check whether gcc is aliased to clang. If so, we recommend
installing gcc using homebrew, then run

  export CC=gcc-14

in the terminal directly before installing ore_algebra.

### With Sage installed from operating system packages

If your copy of Sage comes from operating system packages (e.g., Debian, Ubuntu,
Gentoo, or Arch Linux packages), try replacing `sage -pip` by `pip` or `pip3`
above.

You may need development packages that are not automatically installed as
dependencies of the main SageMath package, e.g., a C/C++ compiler, the Cython
compiler, and header files for Linbox, Pari, and Singular.

For example, Debian and Ubuntu users need to install the `liblinbox-dev`,
`libpari-dev` and `libsingular-dev` packages (and possibly others) in addition
to the `sagemath package`. The command `apt build-dep sagemath` can be used to
install all necessary development packages (and more).

Arch Linux users will need at least the `cython` and `python-pkgconfig`
packages.

### Using ore_algebra in a virtual Python environment (no SageMath installation required)

Create and activate a virtual environment:

    python3 -m venv venv_ore_algebra
    . venv_ore_algebra/bin/activate

Install the package in the virtual environment:

    pip install "ore_algebra[passagemath] @ git+https://github.com/mkauers/ore_algebra.git"

This automatically installs the modularized parts of the Sage library that are
needed by the package. (These modularized distributions are provided by
https://github.com/passagemath.)

Documentation
-------------

The documentation generated from the doc strings is available online at

- http://www.algebra.uni-linz.ac.at/people/mkauers/ore_algebra

Testing
-------

To run the test suite, install the package and run the command

    sage -tp --long --force-lib src/

at the root of the git checkout.

Contact
-------

Manuel Kauers <manuel@kauers.de>
